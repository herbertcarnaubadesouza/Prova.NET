﻿$(document).ready(function () {
    $(".alert-success").delay(1000).fadeOut(3000);
});